# electron-text-editor

https://qiita.com/koedamon/items/e2f858511863dcc4852e
